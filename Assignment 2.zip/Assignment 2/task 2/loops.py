import timeit

OTP = "4821"
SECURITY_ANSWER = "chennai"
GRANTED = "Access granted"
LOCKED = "Account locked for 30 minutes"

def while_version(entries):
    entries = list(entries)
    attempts = 0
    result = ""
    while attempts < 3:
        entry = entries.pop(0)
        if entry == "":
            continue
        attempts += 1
        if entry == OTP:
            result = GRANTED
            break
    else:
        result = LOCKED
    return result

def for_version(entries):
    entries = list(entries)
    result = ""
    for attempt in range(3):
        while True:
            entry = entries.pop(0)
            if entry == "":
                pass
            else:
                break
        if entry == OTP:
            result = GRANTED
            break
    else:
        result = LOCKED
    return result

def buggy_while(entries):
    entries = list(entries)
    attempts = 0
    result = ""
    while attempts < 3:
        entry = entries.pop(0)
        attempts += 1                # BUG: counted before the blank check
        if entry == "":
            continue
        if entry == OTP:
            result = GRANTED
            break
    else:
        result = LOCKED
    return result

def extended_while(entries, security_answer):
    entries = list(entries)
    limit = 3
    attempts = 0
    extended = False
    result = ""

    while attempts < limit:
        if not entries:
            break
        entry = entries.pop(0)
        if entry == "":
            continue

        attempts += 1
        if entry == OTP:
            result = GRANTED
            break

        if attempts == limit and not extended and security_answer == SECURITY_ANSWER:
            limit = 5                # two extra attempts
            extended = True
    else:
        result = LOCKED

    return result

def recursive_version(entries, attempts=0):
    if attempts == 3:
        return LOCKED
    entry = entries.pop(0)
    if entry == "":
        return recursive_version(entries, attempts)       # blank: same attempt number
    if entry == OTP:
        return GRANTED
    return recursive_version(entries, attempts + 1)       # wrong: next attempt

scenarios = [
    ("Correct on 1st try",        ["4821"]),
    ("Correct on 3rd try",        ["1111", "2222", "4821"]),
    ("Blanks do not count",       ["1111", "", "2222", "4821"]),
    ("Three wrong -> locked",     ["1111", "2222", "3333"]),
    ("Blanks then 3 wrong",       ["", "", "1111", "2222", "3333"]),
 ]

print("=" * 88)
print(f"{'Scenario':<24}{'while':<30}{'for':<30}")
print("=" * 88)
for name, entries in scenarios:
    print(f"{name:<24}{while_version(entries):<30}{for_version(entries):<30}")

print("\nRecursion version (same scenarios):")
for name, entries in scenarios:
   print(f"  {name:<24}{recursive_version(list(entries))}")

print("\nBug demo (counter updated before the blank check):")
demo = ["1111", "", "2222", "4821"]
print("  Entries            :", demo)
print("  Correct while loop :", while_version(demo))
print("  Buggy while loop   :", buggy_while(demo), "<-- wrong! blank was counted")

print("\nChanged condition (2 extra attempts after the security question):")
five = ["1111", "2222", "3333", "4444", "4821"]
print("  Right security answer:", extended_while(five, "chennai"))
print("  Wrong security answer:", extended_while(five, "delhi"))
print("  Right answer, 5 wrong:", extended_while(["1", "2", "3", "4", "5"], "chennai"))
print("\nTiming 100000 runs of the worst case (3 wrong entries):")
worst = ["1111", "2222", "3333"]
runs = 100000
t1 = timeit.timeit(lambda: while_version(worst), number=runs)
t2 = timeit.timeit(lambda: for_version(worst), number=runs)
t3 = timeit.timeit(lambda: recursive_version(list(worst)), number=runs)
print(f"while loop : {t1:.4f} seconds")
print(f"for loop   : {t2:.4f} seconds")
print(f"recursion  : {t3:.4f} seconds")