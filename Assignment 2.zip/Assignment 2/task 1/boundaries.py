from ctypes import alignment
import timeit

households = [
    (50,  False, False, "Full subsidy"),
    (100, True,  False, "Full subsidy"),      # boundary 100
    (101, True,  False, "Partial subsidy"),   # boundary 101
    (101, False, False, "No subsidy"),        # boundary 101, no card
    (200, True,  False, "Partial subsidy"),   # boundary 200
    (200, False, True,  "No subsidy"),        # age rule does not apply up to 200
    (201, False, True,  "Senior subsidy"),    # boundary 201
    (201, True,  False, "No subsidy"),        # card does not help above 200
 ]

def decide_buggy(units, ration, senior):
    results = []
    if units <= 100:
        results.append("Full subsidy")
    if units <= 200 and ration:              # BUG: no lower limit
        results.append("Partial subsidy")
    if units > 200 and senior:
        results.append("Senior subsidy")
    if not results:
        results.append("No subsidy")
    return results

def decide_separate_if(units, ration, senior):
    results = []
    if units <= 100:
        results.append("Full subsidy")
    if 101 <= units <= 200 and ration:
        results.append("Partial subsidy")
    if units > 200 and senior:
        results.append("Senior subsidy")
    if not results:
        results.append("No subsidy")
    return results

def decide_elif(units, ration, senior):
    if units <= 100:
        return "Full subsidy"
    elif 101 <= units <= 200 and ration:
        return "Partial subsidy"
    elif units > 200 and senior:
        return "Senior subsidy"
    else:
        return "No subsidy"

SLABS = [
    (100, "always"),
    (200, "ration"),
    (float("inf"), "senior"),
 ]
def decide_table(units, ration, senior):
    for limit, rule in SLABS:
        if units <= limit:
            if rule == "always":
                return "Full subsidy"
            if rule == "ration":
                return "Partial subsidy" if ration else "No subsidy"
            return "Senior subsidy" if senior else "No subsidy"

print("=" * 95)
print(f"{'Units':<6}{'Card':<7}{'80+':<7}{'Predicted':<17}{'if-elif-else':<17}"
      f"{'Separate if':<22}{'Buggy ifs':<22}")

print("=" * 95)

all_ok = True
for units, ration, senior, predicted in households:
    a = decide_elif(units, ration, senior)
    b = decide_separate_if(units, ration, senior)
    c = decide_buggy(units, ration, senior)
    d = decide_table(units, ration, senior)

    if a != predicted or b != [predicted] or d != predicted:
        all_ok = False

    print(f"{units:<6}{str(ration):<7}{str(senior):<7}{predicted:<17}{a:<17}"
          f"{', '.join(b):<22}{', '.join(c):<22}")
    if len(c) > 1:
        print("      ^^^ buggy version gave MORE THAN ONE result here!")
print("-" * 95)
print("All predictions match the correct implementations:", all_ok)
print("\nTiming 200000 decisions for the worst case (units=250):")
runs = 200000
t1 = timeit.timeit(lambda: decide_separate_if(250, False, True), number=runs)
t2 = timeit.timeit(lambda: decide_elif(250, False, True), number=runs)
t3 = timeit.timeit(lambda: decide_table(250, False, True), number=runs)
print(f"Separate if   : {t1:.4f} seconds")
print(f"if-elif-else  : {t2:.4f} seconds")
print(f"Lookup table  : {t3:.4f} seconds")