def add_item_buggy(item, order=[]):
            # the [] is created ONCE, when the function is defined
        order.append(item)
        return order

def add_item(item, order=None):
        # TODO 1 (completed)
        if order is None:
            order = []
        order.append(item)
        return order

print("--- Part 1: Bug vs Fix ---")
print(add_item_buggy("Tea"), add_item_buggy("Vada"))
print(add_item("Tea"), add_item("Vada"))

    # Python stores default values in __defaults__
print("Buggy defaults:", add_item_buggy.__defaults__)
print("Fixed defaults:", add_item.__defaults__)

def make_line(item, qty=1, price=10):
        # item  -> positional (required)
        # qty, price -> default parameters (optional)
        return item + " x" + str(qty) + " = Rs." + str(qty * price)

print("\n--- Part 2: Positional, keyword and default parameters ---")
print(make_line("Tea"))                         # positional + defaults
print(make_line("Vada", 2, 12))                 # all positional
print(make_line("Dosa", price=40, qty=2))       # keyword (order does not matter)

def calculate_bill(prices, gst_percent=5):
        total = sum(prices)
        gst = total * gst_percent / 100
        return total, gst            # returns a tuple (total, gst)

print("\n--- Part 3: Returning two values ---")
total, gst = calculate_bill([10, 12, 40])
print("Total:", total, "GST:", gst, "Grand total:", total + gst)

print("\n--- Part 4: Scope ---")

def local_demo():
    message = "I am local"
    print(message)

local_demo()

orders_served = 0

def serve_without_global():
        orders_served = 100
def serve_with_global():
        global orders_served
        orders_served = orders_served + 1

serve_without_global()
print("After serve_without_global:", orders_served)   # still 0
serve_with_global()
print("After serve_with_global:", orders_served)      # 1

def outer():
        count = 0
        
        def inner():

            nonlocal count
            count = count + 1

        inner()
        inner()
        return count

print("Nonlocal demo (inner called twice):", outer())  # 2

def add_item_explicit(item, order):
        order.append(item)
        return order

def new_customer():
        order = []

        def add(item):
            order.append(item)
            return order

        return add

print("\n--- Part 5: Test with three customers ---")

    # Design 1: default None
c1 = add_item("Tea")
c1 = add_item("Vada", c1)
c2 = add_item("Coffee")
c3 = add_item("Dosa")
c3 = add_item("Idli", c3)
print("Customer 1:", c1)
print("Customer 2:", c2)
print("Customer 3:", c3)

    # Design 2: explicit list
a1, a2, a3 = [], [], []
add_item_explicit("Tea", a1)
add_item_explicit("Coffee", a2)
add_item_explicit("Dosa", a3)
print("Explicit  :", a1, a2, a3)

    # Design 3: closure
cust1 = new_customer()
cust2 = new_customer()
cust3 = new_customer()
cust1("Tea")
cust1("Vada")
cust2("Coffee")
print("Closure   :", cust1("Samosa"), cust2("Biscuit"), cust3("Dosa"))