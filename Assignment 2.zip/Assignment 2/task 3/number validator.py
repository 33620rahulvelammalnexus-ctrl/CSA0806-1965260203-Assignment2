import re
import timeit

def normalise(text):
         """'tn 09 ab 1234' -> 'TN09AB1234' (spaces and hyphens removed, upper case)."""
         return text.strip().replace(" ", "").replace("-", "").upper()

def is_valid(reg):
        """Valid form: 2 letters, 2 digits, 1 or 2 letters, 4 digits (e.g. TN09AB1234)."""
        if len(reg) != 9 and len(reg) != 10:
                return False
        state = reg[:2]          # first 2 characters
        district = reg[2:4]      # next 2 characters
        series = reg[4:-4]       # everything between, 1 or 2 characters
        number = reg[-4:]        # last 4 characters
        return (state.isalpha() and district.isdigit()
                        and series.isalpha() and number.isdigit())

def format_plate(reg):
        """'TN09AB1234' -> 'TN 09 AB 1234'"""
        if not is_valid(reg):
                return "Cannot format: invalid number"
        return " ".join([reg[:2], reg[2:4], reg[4:-4], reg[-4:]])

def is_valid_regex(reg):
        return re.fullmatch(r"[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}", reg) is not None

print("PART 1: Given test loop")
for raw in ["tn 09 ab 1234", "KA-01-M-0007", "TN9AB1234", "TN 22 1234 AB"]:
        reg = normalise(raw)
        print(f"{raw:15} -> {reg:11} {'valid' if is_valid(reg) else 'INVALID'}")

predictions = [
        ("tn 09 ab 1234",  "TN09AB1234",  True),
        ("TN-09-AB-1234",  "TN09AB1234",  True),
        ("Tn09Ab1234",     "TN09AB1234",  True),
        ("ka-01-m-0007",   "KA01M0007",   True),
        ("TN 09 ABC 1234", "TN09ABC1234", False),   # length 11, rejected
        ("TN 0A AB 1234",  "TN0AAB1234",  False),   # '0A' is not 2 digits, rejected
    ]

print("\nPART 2: Predicted vs observed")
print(f"{'Typed':<16}{'Normalised':<13}{'Valid':<7}{'Receipt format':<18}{'Match'}")
print("-" * 62)
all_ok = True
for raw, pred_reg, pred_valid in predictions:
        reg = normalise(raw)
        valid = is_valid(reg)
        match = (reg == pred_reg and valid == pred_valid
                         and valid == is_valid_regex(reg))
        if not match:
                all_ok = False
        print(f"{raw:<16}{reg:<13}{str(valid):<7}{format_plate(reg):<18}{match}")
print("-" * 62)
print("All predictions correct:", all_ok)

print("\nPART 3: Slicing demo")
for plate in ["KA01M0007", "TN09AB1234"]:
        print(f"{plate} (length {len(plate)}): s[-4:] = {plate[-4:]!r}, s[4:-4] = {plate[4:-4]!r}")

text = "tn09ab1234"
text.upper()
print("\nAfter text.upper() without saving:", text)
text = text.upper()
print("After text = text.upper()         :", text)

try:
        text[0] = "X"
except TypeError as error:
        print("Trying text[0] = 'X' gives TypeError:", error)

print("\nPART 4: Timing 200000 validations of 'TN09AB1234'")
runs = 200000
t1 = timeit.timeit(lambda: is_valid("TN09AB1234"), number=runs)
t2 = timeit.timeit(lambda: is_valid_regex("TN09AB1234"), number=runs)
print(f"Slicing + string methods : {t1:.4f} seconds")
print(f"Regular expression       : {t2:.4f} seconds")