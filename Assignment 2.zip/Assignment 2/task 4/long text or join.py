import time

    # ---------- Data ---------
items = [f"Item{i}:Rs{i % 50}" for i in range(200_000)]

    # ---------- (a) repeated += ---------
def build_plus(parts):
        text = ""
        for p in parts:
            text += p + ";"
        return text

    # ---------- (b) list of parts + join() ---------
def build_join(parts):
        # TODO 1 (completed): single str.join() call
        return "".join([p + ";" for p in parts])

    # ---------- (c) f-string for each line, then join ---------
def build_fstring(parts):
        lines = []
        for p in parts:
            lines.append(f"{p};")
        return "".join(lines)

    # ---------- Part 1: the given check ---------
start = time.perf_counter(); a = build_plus(items); t_plus = time.perf_counter() - start
start = time.perf_counter(); b = build_join(items); t_join = time.perf_counter() - start

print("same text:", a == b, "| length:", len(b))
print(f"+= time: {t_plus:.4f} s   join time: {t_join:.4f} s")
print()

    # ---------- Part 2: measure all three at 1,000 / 10,000 / 200,000 lines ---------
def measure(func, data):
        start = time.perf_counter()
        func(data)
        return time.perf_counter() - start

sizes = [1_000, 10_000, 200_000]
runs = 3

print(f"{'Lines':>8} | {'+= (s)':>10} | {'join (s)':>10} | {'f-string (s)':>12}")
print("-" * 50)

for n in sizes:
    data = items[:n]
    total_plus = total_join = total_f = 0

    for _ in range(runs):
        total_plus += measure(build_plus, data)
        total_join += measure(build_join, data)
        total_f += measure(build_fstring, data)

print(f"{n:>8} | {total_plus / runs:>10.5f} | {total_join / runs:>10.5f} | {total_f /runs:>12.5f}")

    # ---------- Part 3: all three give the same text ---------
print()
print("All three equal:", build_plus(items) == build_join(items) == build_fstring(items))