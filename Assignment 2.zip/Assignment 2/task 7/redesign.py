import time

# ---------- ORIGINAL: plain recursion (from Q6) ----------
calls = 0

def ways_naive(n):
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)


# ---------- REDESIGN: loop keeping only the last two values ----------
additions = 0

def ways_loop(n):
    global additions
    a, b = 1, 1                      # ways for 0 steps and 1 step
    for _ in range(n - 1):
        a, b = b, a + b              # each new value = sum of previous two
        additions += 1
    return b


def time_it(func, n, repeats):
    """Average time in seconds for one run of func(n)."""
    start = time.perf_counter()
    for _ in range(repeats):
        func(n)
    return (time.perf_counter() - start) / repeats


print("=== Original (naive recursion) vs Redesign (loop), same inputs ===")
print("n    answers_equal   naive_calls   loop_additions   naive_time(s)   loop_time(s)   speed-up")
for n in (10, 20, 25, 30):
    calls = 0
    answer_old = ways_naive(n)
    naive_calls = calls

    additions = 0
    answer_new = ways_loop(n)
    loop_adds = additions

    t_old = time_it(ways_naive, n, 3)
    t_new = time_it(ways_loop, n, 1000)
    print(n, "  ", answer_old == answer_new, "         ", naive_calls, "     ",
          loop_adds, "          ", format(t_old, ".6f"), "     ",
          format(t_new, ".8f"), "   ", round(t_old / t_new), "x")

print("\n=== Redesign for n = 1000 (original cannot finish) ===")
additions = 0
big = ways_loop(1000)
print("Additions:", additions, " Digits in answer:", len(str(big)))
print("Time (s):", format(time_it(ways_loop, 1000, 100), ".8f"))

print("\n=== Correctness check n = 1 to 6 (hand answers: 1, 2, 3, 5, 8, 13) ===")
hand = [1, 2, 3, 5, 8, 13]
for n in range(1, 7):
    print("n =", n, "loop =", ways_loop(n), "naive =", ways_naive(n), "match =", ways_loop(n) == ways_naive(n) == hand[n - 1])

print("\n=== Why the original cannot do n = 1000 ===")
print("Naive calls for n = 30:", 2692537, "-> each +1 step multiplies calls by about 1.618")
print("Estimated naive calls for n = 1000: about 10 ** 209 (impossible to finish)")