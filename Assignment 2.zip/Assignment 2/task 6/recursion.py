import sys
from functools import lru_cache

calls = 0


# ---------- 1. Plain recursion ----------
def ways_naive(n):
    """Ways to climb n temple steps taking 1 or 2 steps at a time."""
    global calls
    calls += 1
    if n <= 1:                                   # base case
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)  # recursive case


# ---------- 2. Recursion with memoisation ----------
@lru_cache(maxsize=None)
def ways_memo(n):
    global calls
    calls += 1
    if n <= 1:                                   # TODO 1: same base case
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)   # TODO 1: same recursive case


# ---------- 3. Loop keeping only the last two values ----------
def ways_loop(n):
    a, b = 1, 1                                  # ways for steps 0 and 1
    for _ in range(n - 1):
        a, b = b, a + b
    return b


# ---------- Call tree for n = 5 ----------
def show_tree(n, indent=0):
    print("    " * indent + "ways(" + str(n) + ")")
    if n > 1:
        show_tree(n - 1, indent + 1)
        show_tree(n - 2, indent + 1)


print("=== Call tree for n = 5 ===")
show_tree(5)
print("ways(3) is computed 2 times, ways(2) 3 times, ways(1) 5 times: repeated work")

# ---------- Required output ----------
print("\n=== Expected output check (n = 25) ===")
calls = 0; print("naive:", ways_naive(25), "calls =", calls)
ways_memo.cache_clear()
calls = 0; print("memo :", ways_memo(25), "calls =", calls)

# ---------- Correctness check ----------
print("\n=== Correctness check n = 1 to 6 (hand answers: 1, 2, 3, 5, 8, 13) ===")
hand = [1, 2, 3, 5, 8, 13]
for n in range(1, 7):
    ok = ways_naive(n) == ways_memo(n) == ways_loop(n) == hand[n - 1]
    print("n =", n, "ways =", ways_loop(n), "match =", ok)

# ---------- Growth investigation ----------
print("\n=== Growth investigation: number of calls ===")
print("n    naive_calls   memo_calls")
for n in (10, 20, 25, 30):
    calls = 0; ways_naive(n); naive_calls = calls
    ways_memo.cache_clear()
    calls = 0; ways_memo(n); memo_calls = calls
    print(n, "  ", naive_calls, "  ", memo_calls)
print("Prediction: naive calls grow about 1.618 times per extra step; memo calls = n + 1")

# ---------- Deployment decision: n = 1000 ----------
print("\n=== n = 1000 ===")
print("Recursion limit:", sys.getrecursionlimit())
ways_memo.cache_clear()
try:
    ways_memo(1000)
    print("memo n=1000 worked")
except RecursionError:
    print("RecursionError: recursion depth reached about 1000 (the limit), so Python stopped it")

ways_memo.cache_clear()
sys.setrecursionlimit(5000)
big_memo = ways_memo(1000)
print("After raising limit to 5000, memo works. Digits in answer:", len(str(big_memo)))

big_loop = ways_loop(1000)
print("Loop version works with no limit change. Digits in answer:", len(str(big_loop)))
print("All three-style answers equal:", big_memo == big_loop)
print("ways(1000) =", big_loop)